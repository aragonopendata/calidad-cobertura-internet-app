var constantes = {
    
};