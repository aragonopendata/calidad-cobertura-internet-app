function DatosCobertura (timestamp, coordenadax, coordenaday, coordenadax5000, coordenaday5000, coordenadax20000, coordenaday20000, municipio, ine, modelo, so, tipoRed, operador, valorIntensidadSenial, rangoIntensidadSenial, velocidadBajada, velocidadSubida, latencia, datosConexionLimpiados, ubicacionManual) {
	this.timestamp = timestamp;
	this.coordenadax = coordenadax;
	this.coordenaday = coordenaday;
	this.coordenadax5000 = coordenadax5000;
	this.coordenaday5000 = coordenaday5000;
	this.coordenadax20000 = coordenadax20000;
	this.coordenaday20000 = coordenaday20000;
	this.municipio = municipio;
	this.ine = ine;
	this.modelo = modelo;
	this.so = so;
	this.tipoRed = tipoRed;
	this.operador = operador;
	this.valorIntensidadSenial = valorIntensidadSenial;
	this.rangoIntensidadSenial = rangoIntensidadSenial;
	this.velocidadBajada = velocidadBajada;
	this.velocidadSubida = velocidadSubida;
	this.latencia = latencia;
	this.datosConexionLimpiados = datosConexionLimpiados;
	this.ubicacionManual = ubicacionManual;
}